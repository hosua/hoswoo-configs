#! /bin/bash 
picom &
nitrogen --restore &
dwmblocks &
